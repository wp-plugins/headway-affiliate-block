=== Headway Affiliate Block ===
Contributors: ch0cbk0b3ar
Donate link: http://headway101.com/blocks/affiliate/
Tags: affiliate, headway themes, headway blocks
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 1.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Easily add a "Powered by Headway Themes" message anywhere on your website and generate affiliate revenue.

== Description ==

The "Headway Affiliate Block" is an add-on block for [Headway Themes]: http://headwaythemes.com that lets you easily add a "powered by headway themes" message anywhere on your website. You can select one of the headway themes official affiliate banners to display alongside your message, and benefit from copy optimized to increase affiliate conversions.

== Installation ==

1. Upload the `headway-affiliate-block` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Open the Headway Visual Editor in Grid Mode
1. Create a new block and choose "Affiliate" to add the block to your layouts.

== Frequently Asked Questions ==

= Do you have to have Headway Themes installed to use this plugin? =

Yes. This plugin is built specifically for Headway Themes.